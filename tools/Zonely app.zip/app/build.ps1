# Builds Zonely.exe using only what ships with Windows (no Node/SDK needed).
# Usage: powershell -ExecutionPolicy Bypass -File build.ps1
$ErrorActionPreference = "Stop"

$htmlSrc = Join-Path $PSScriptRoot "..\files\Zonely-v2.html"
$html    = Join-Path $PSScriptRoot "Zonely.html"
$ico     = Join-Path $PSScriptRoot "zonely.ico"
$exe     = Join-Path $PSScriptRoot "Zonely.exe"
$cs      = Join-Path $PSScriptRoot "ZonelyLauncher.cs"

# 1) pull in the latest app HTML
Copy-Item $htmlSrc $html -Force

# 2) build zonely.ico from the app's own favicon (16/32/48 BMP + 256 PNG entries)
function New-ZonelyIcon([string]$htmlPath, [string]$icoPath) {
    Add-Type -AssemblyName System.Drawing
    $text = [IO.File]::ReadAllText($htmlPath)
    if ($text -notmatch 'data:image/png;base64,([A-Za-z0-9+/=]+)') { throw "favicon not found in $htmlPath" }
    $png = [Convert]::FromBase64String($Matches[1])
    $srcStream = New-Object IO.MemoryStream(,$png)
    $src = [System.Drawing.Image]::FromStream($srcStream)

    $entries = @()
    foreach ($s in 16,32,48,256) {
        $bmp = New-Object System.Drawing.Bitmap($s, $s)
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $g.Clear([System.Drawing.Color]::Transparent)
        $g.DrawImage($src, 0, 0, $s, $s)
        $g.Dispose()

        if ($s -eq 256) {
            # PNG-compressed entry (standard for 256px)
            $out = New-Object IO.MemoryStream
            $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
            $data = $out.ToArray()
        } else {
            # classic uncompressed DIB entry: header + BGRA rows bottom-up + empty AND mask
            $rect = New-Object System.Drawing.Rectangle(0, 0, $s, $s)
            $bd = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly,
                                [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
            $pixels = New-Object byte[] ($bd.Stride * $s)
            [Runtime.InteropServices.Marshal]::Copy($bd.Scan0, $pixels, 0, $pixels.Length)
            $bmp.UnlockBits($bd)

            $dib = New-Object IO.MemoryStream
            $w = New-Object IO.BinaryWriter($dib)
            $w.Write([UInt32]40); $w.Write([Int32]$s); $w.Write([Int32]($s * 2))   # BITMAPINFOHEADER (height doubled for mask)
            $w.Write([UInt16]1);  $w.Write([UInt16]32)                             # planes, bpp
            $w.Write([UInt32]0);  $w.Write([UInt32]0)                              # compression, image size
            $w.Write([Int32]0);   $w.Write([Int32]0); $w.Write([UInt32]0); $w.Write([UInt32]0)
            for ($y = $s - 1; $y -ge 0; $y--) { $w.Write($pixels, $y * $bd.Stride, $s * 4) }
            $maskRow = New-Object byte[] ([Math]::Ceiling($s / 32) * 4)
            for ($y = 0; $y -lt $s; $y++) { $w.Write($maskRow) }
            $w.Flush()
            $data = $dib.ToArray()
        }
        $entries += ,@{ Size = $s; Data = $data }
        $bmp.Dispose()
    }
    $src.Dispose()

    $icoStream = New-Object IO.MemoryStream
    $bw = New-Object IO.BinaryWriter($icoStream)
    $bw.Write([UInt16]0); $bw.Write([UInt16]1); $bw.Write([UInt16]$entries.Count)  # ICONDIR
    $offset = 6 + 16 * $entries.Count
    foreach ($e in $entries) {
        $sz = if ($e.Size -ge 256) { 0 } else { $e.Size }                          # 0 means 256
        $bw.Write([Byte]$sz); $bw.Write([Byte]$sz); $bw.Write([Byte]0); $bw.Write([Byte]0)
        $bw.Write([UInt16]1); $bw.Write([UInt16]32)
        $bw.Write([UInt32]$e.Data.Length); $bw.Write([UInt32]$offset)
        $offset += $e.Data.Length
    }
    foreach ($e in $entries) { $bw.Write($e.Data) }
    $bw.Flush()
    [IO.File]::WriteAllBytes($icoPath, $icoStream.ToArray())
}

$iconArg = $null
try {
    New-ZonelyIcon $html $ico
    $iconArg = "/win32icon:$ico"
    Write-Host "Icon generated: $ico"
} catch {
    Write-Warning "Icon generation failed ($($_.Exception.Message)) - building without icon"
}

# 3) compile with the stock .NET Framework C# compiler
$csc = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$cscArgs = @(
    "/nologo", "/target:winexe", "/out:$exe",
    "/r:System.Windows.Forms.dll",
    "/resource:$html,Zonely.html"
)
if ($iconArg) { $cscArgs += $iconArg }
$cscArgs += $cs

& $csc $cscArgs
if ($LASTEXITCODE -ne 0) { throw "csc.exe failed with exit code $LASTEXITCODE" }
Write-Host "Built $exe"
