// Zonely launcher — extracts the embedded app HTML and opens it as a
// chrome-less Edge app window, then gives that window Zonely's own taskbar
// identity (icon, name, relaunch target) instead of Edge's.
// No installs, no network, no admin rights. Built with the stock .NET
// Framework compiler; see build.ps1.
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32;

static class ZonelyLauncher
{
    [STAThread]
    static void Main()
    {
        try
        {
            string dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Zonely");
            Directory.CreateDirectory(dir);
            string html = Path.Combine(dir, "Zonely.html");

            // overwrite on every run so shipping a new exe updates the app
            Assembly asm = Assembly.GetExecutingAssembly();
            using (Stream src = asm.GetManifestResourceStream("Zonely.html"))
            using (FileStream dst = File.Create(html))
            {
                src.CopyTo(dst);
            }

            string url = "file:///" + html.Replace('\\', '/');
            string edge = FindEdge();
            if (edge != null)
            {
                Process.Start(edge, "--app=\"" + url + "\" --window-size=480,900");
                BrandTaskbarWindow(); // swap the Edge taskbar identity for Zonely's
            }
            else
            {
                Process.Start(html); // no Edge (unlikely on Win10/11): default browser
            }
        }
        catch (Exception ex)
        {
            System.Windows.Forms.MessageBox.Show(
                "Zonely could not start:\r\n" + ex.Message, "Zonely");
        }
    }

    static string FindEdge()
    {
        string[] guesses = {
            Environment.ExpandEnvironmentVariables(@"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
            Environment.ExpandEnvironmentVariables(@"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe")
        };
        foreach (string g in guesses)
            if (File.Exists(g)) return g;

        using (RegistryKey k = Registry.LocalMachine.OpenSubKey(
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe"))
        {
            if (k != null)
            {
                string v = k.GetValue(null) as string;
                if (v != null && File.Exists(v)) return v;
            }
        }
        return null;
    }

    /* ---------- taskbar identity (App User Model ID) ---------- */

    static void BrandTaskbarWindow()
    {
        string exePath = Assembly.GetExecutingAssembly().Location;

        IntPtr hwnd = IntPtr.Zero;
        for (int i = 0; i < 40 && hwnd == IntPtr.Zero; i++) // wait up to ~20 s for the window
        {
            Thread.Sleep(500);
            hwnd = FindZonelyWindow();
        }
        if (hwnd == IntPtr.Zero) return;

        ApplyIdentity(hwnd, exePath);
        Thread.Sleep(1500);              // Edge can re-assert its own id just after startup
        ApplyIdentity(hwnd, exePath);
    }

    delegate bool EnumProc(IntPtr hwnd, IntPtr lParam);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr lParam);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int max);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern int GetClassName(IntPtr hwnd, StringBuilder text, int max);

    static IntPtr _found;
    static IntPtr FindZonelyWindow()
    {
        _found = IntPtr.Zero;
        EnumWindows(delegate(IntPtr h, IntPtr l)
        {
            if (!IsWindowVisible(h)) return true;
            StringBuilder t = new StringBuilder(64);
            GetWindowText(h, t, 64);
            if (t.ToString() != "Zonely") return true;
            StringBuilder c = new StringBuilder(64);
            GetClassName(h, c, 64);
            if (c.ToString() != "Chrome_WidgetWin_1") return true; // Edge top-level window class
            _found = h;
            return false;
        }, IntPtr.Zero);
        return _found;
    }

    [ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IPropertyStore
    {
        int GetCount(out uint count);
        int GetAt(uint index, out PropertyKey key);
        int GetValue(ref PropertyKey key, out PropVariant value);
        int SetValue(ref PropertyKey key, ref PropVariant value);
        int Commit();
    }

    [StructLayout(LayoutKind.Sequential)]
    struct PropertyKey
    {
        public Guid fmtid;
        public uint pid;
        public PropertyKey(Guid f, uint p) { fmtid = f; pid = p; }
    }

    [StructLayout(LayoutKind.Explicit)]
    struct PropVariant
    {
        [FieldOffset(0)] public ushort vt;
        [FieldOffset(8)] public IntPtr ptr; // union payload
    }

    [DllImport("shell32.dll")]
    static extern int SHGetPropertyStoreForWindow(IntPtr hwnd, ref Guid riid,
        [MarshalAs(UnmanagedType.Interface)] out IPropertyStore store);

    static void SetString(IPropertyStore ps, PropertyKey key, string value)
    {
        PropVariant pv = new PropVariant();
        pv.vt = 31; // VT_LPWSTR
        pv.ptr = Marshal.StringToCoTaskMemUni(value);
        try { ps.SetValue(ref key, ref pv); }
        finally { Marshal.FreeCoTaskMem(pv.ptr); }
    }

    static void ApplyIdentity(IntPtr hwnd, string exePath)
    {
        try
        {
            Guid iid = new Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99");
            IPropertyStore ps;
            if (SHGetPropertyStoreForWindow(hwnd, ref iid, out ps) != 0 || ps == null) return;

            Guid fmt = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"); // PKEY_AppUserModel_*
            SetString(ps, new PropertyKey(fmt, 5), "Zonely.TimezoneApp");       // ID (own taskbar group)
            SetString(ps, new PropertyKey(fmt, 2), "\"" + exePath + "\"");      // RelaunchCommand
            SetString(ps, new PropertyKey(fmt, 4), "Zonely");                   // RelaunchDisplayName
            SetString(ps, new PropertyKey(fmt, 3), exePath + ",0");             // RelaunchIconResource
            ps.Commit();
            Marshal.ReleaseComObject(ps);
        }
        catch { /* branding is cosmetic — never block launch */ }
    }
}
